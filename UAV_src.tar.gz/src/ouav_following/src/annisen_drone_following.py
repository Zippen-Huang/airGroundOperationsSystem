#!/usr/bin/env python2

import rospy
from geometry_msgs.msg import TwistStamped
from mavros_msgs.srv import SetMode, SetMavFrame
from mavros_msgs.msg import State
from apriltags2_ros.msg import AprilTagDetectionArray

class AnnisenDroneFollowing():
    def __init__(self):
        rospy.init_node('annisen_drone_following')
        self.vel_pub = rospy.Publisher('/mavros/setpoint_velocity/cmd_vel', TwistStamped, queue_size=5)

        self.state = State()
        rospy.Subscriber('/mavros/state', State, self.state_cb)
        rospy.Subscriber('/tag_detections', AprilTagDetectionArray, self.pose_cb)

        rospy.wait_for_service('/mavros/set_mode', 2.0)
        rospy.wait_for_service('/mavros/setpoint_velocity/mav_frame', 2.0)
        self.set_mode_srv = rospy.ServiceProxy('/mavros/set_mode', SetMode)
        self.set_mav_frame_srv = rospy.ServiceProxy('/mavros/setpoint_velocity/mav_frame', SetMavFrame)
        while self.state.mode != 'GUIDED':
            self.set_mode_srv(0, 'GUIDED')
            rospy.sleep(1.0)
        rospy.loginfo('Flight mode changed to GUIDED.') 
        self.set_mav_frame_srv(9)

        rospy.on_shutdown(self.set_poshold)

    def set_poshold(self):
        self.set_mode_srv(0, 'POSHOLD')
        rospy.loginfo('Flight mode changed to POSHOLD.')

    def state_cb(self, msg):
        self.state = msg

    def pose_cb(self, msg):
        vel_cmd = TwistStamped()
        if len(msg.detections) > 0: 
            if msg.detections[0].id[0] == 0:
                tmp_pose = msg.detections[0].pose.pose.pose
                target_pose = [tmp_pose.position.x, tmp_pose.position.y, tmp_pose.position.z]
                vel_cmd.twist.linear.x = -target_pose[0] * 0.4
                vel_cmd.twist.linear.y = target_pose[1] * 0.4
                vel_cmd.twist.linear.z = (1.0 - target_pose[2]) * 0.5
                print (vel_cmd.twist.linear.x, vel_cmd.twist.linear.y, vel_cmd.twist.linear.z)
        self.vel_pub.publish(vel_cmd)

if __name__ == '__main__':
    AnnisenDroneFollowing()
    rospy.spin()


